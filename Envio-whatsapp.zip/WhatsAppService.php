<?php

namespace WhatsAppPlugin;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class WhatsAppService
{
    private $client;
    private $accessToken;
    private $phoneNumberId;
    private $baseUrl = 'https://graph.facebook.com/v18.0';

    public function __construct($accessToken, $phoneNumberId)
    {
        $this->accessToken = $accessToken;
        $this->phoneNumberId = $phoneNumberId;
        $this->client = new Client([
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->accessToken,
                'Content-Type' => 'application/json',
            ]
        ]);
    }

    /**
     * Envía un mensaje de texto simple
     */
    public function sendTextMessage($to, $message)
    {
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->formatPhoneNumber($to),
            'type' => 'text',
            'text' => [
                'body' => $message
            ]
        ];

        return $this->makeRequest('POST', "/{$this->phoneNumberId}/messages", $data);
    }

    /**
     * Envía una factura como documento PDF
     */
    public function sendInvoice($to, $invoiceUrl, $caption = 'Su factura está lista')
    {
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->formatPhoneNumber($to),
            'type' => 'document',
            'document' => [
                'link' => $invoiceUrl,
                'caption' => $caption,
                'filename' => 'factura.pdf'
            ]
        ];

        return $this->makeRequest('POST', "/{$this->phoneNumberId}/messages", $data);
    }

    /**
     * Envía una notificación de trabajo
     */
    public function sendJobNotification($to, $jobTitle, $jobDate, $jobAddress, $jobDescription = '')
    {
        $message = "🔧 *Nuevo Trabajo Programado*\n\n";
        $message .= "*Título:* {$jobTitle}\n";
        $message .= "*Fecha:* {$jobDate}\n";
        $message .= "*Dirección:* {$jobAddress}\n";
        
        if (!empty($jobDescription)) {
            $message .= "*Descripción:* {$jobDescription}\n";
        }
        
        $message .= "\nPor favor confirme su disponibilidad.";

        return $this->sendTextMessage($to, $message);
    }

    /**
     * Envía una notificación de factura pendiente
     */
    public function sendInvoiceNotification($to, $invoiceNumber, $amount, $dueDate)
    {
        $message = "📄 *Factura Pendiente*\n\n";
        $message .= "*Número de Factura:* {$invoiceNumber}\n";
        $message .= "*Monto:* $" . number_format($amount, 2) . "\n";
        $message .= "*Fecha de Vencimiento:* {$dueDate}\n\n";
        $message .= "Su factura está lista para revisión.";

        return $this->sendTextMessage($to, $message);
    }

    /**
     * Envía un mensaje con botones interactivos
     */
    public function sendInteractiveMessage($to, $header, $body, $buttons)
    {
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $this->formatPhoneNumber($to),
            'type' => 'interactive',
            'interactive' => [
                'type' => 'button',
                'header' => [
                    'type' => 'text',
                    'text' => $header
                ],
                'body' => [
                    'text' => $body
                ],
                'action' => [
                    'buttons' => $buttons
                ]
            ]
        ];

        return $this->makeRequest('POST', "/{$this->phoneNumberId}/messages", $data);
    }

    /**
     * Verifica el estado de un mensaje
     */
    public function getMessageStatus($messageId)
    {
        return $this->makeRequest('GET', "/{$messageId}");
    }

    /**
     * Formatea el número de teléfono para WhatsApp
     */
    private function formatPhoneNumber($phone)
    {
        // Elimina caracteres no numéricos
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        // Asegura que tenga el código de país
        if (strlen($phone) === 10) {
            $phone = '1' . $phone; // Asume código de país 1 (Estados Unidos/Canadá)
        }
        
        return $phone;
    }

    /**
     * Realiza una petición HTTP a la API de WhatsApp
     */
    private function makeRequest($method, $endpoint, $data = null)
    {
        try {
            $url = $this->baseUrl . $endpoint;
            $options = [];

            if ($data && $method === 'POST') {
                $options['json'] = $data;
            }

            $response = $this->client->request($method, $url, $options);
            return json_decode($response->getBody()->getContents(), true);
        } catch (RequestException $e) {
            $error = [
                'error' => true,
                'message' => $e->getMessage(),
                'response' => $e->hasResponse() ? json_decode($e->getResponse()->getBody()->getContents(), true) : null
            ];
            
            error_log('WhatsApp API Error: ' . json_encode($error));
            return $error;
        }
    }

    /**
     * Valida la configuración de la API
     */
    public function validateConfiguration()
    {
        if (empty($this->accessToken)) {
            return ['error' => true, 'message' => 'Access Token no configurado'];
        }

        if (empty($this->phoneNumberId)) {
            return ['error' => true, 'message' => 'Phone Number ID no configurado'];
        }

        // Intenta obtener información del número de teléfono
        $result = $this->makeRequest('GET', "/{$this->phoneNumberId}");
        
        if (isset($result['error'])) {
            return ['error' => true, 'message' => 'Configuración inválida: ' . $result['error']['message']];
        }

        return ['error' => false, 'message' => 'Configuración válida', 'data' => $result];
    }
} 