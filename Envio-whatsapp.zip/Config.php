<?php

namespace WhatsAppPlugin;

class Config
{
    private static $configFile = __DIR__ . '/../data/config.json';
    
    /**
     * Obtiene la configuración actual
     */
    public static function get($key = null)
    {
        $config = self::loadConfig();
        
        if ($key === null) {
            return $config;
        }
        
        return isset($config[$key]) ? $config[$key] : null;
    }
    
    /**
     * Establece una configuración
     */
    public static function set($key, $value)
    {
        $config = self::loadConfig();
        $config[$key] = $value;
        self::saveConfig($config);
    }
    
    /**
     * Obtiene las credenciales de WhatsApp
     */
    public static function getWhatsAppCredentials()
    {
        return [
            'access_token' => self::get('whatsapp_access_token'),
            'phone_number_id' => self::get('whatsapp_phone_number_id'),
            'business_account_id' => self::get('whatsapp_business_account_id')
        ];
    }
    
    /**
     * Verifica si la configuración de WhatsApp está completa
     */
    public static function isWhatsAppConfigured()
    {
        $credentials = self::getWhatsAppCredentials();
        return !empty($credentials['access_token']) && !empty($credentials['phone_number_id']);
    }
    
    /**
     * Obtiene la configuración de notificaciones
     */
    public static function getNotificationSettings()
    {
        return [
            'send_job_notifications' => self::get('send_job_notifications') ?? true,
            'send_invoice_notifications' => self::get('send_invoice_notifications') ?? true,
            'auto_send_invoices' => self::get('auto_send_invoices') ?? false,
            'notification_template' => self::get('notification_template') ?? 'default'
        ];
    }
    
    /**
     * Carga la configuración desde el archivo
     */
    private static function loadConfig()
    {
        if (!file_exists(self::$configFile)) {
            return self::getDefaultConfig();
        }
        
        $content = file_get_contents(self::$configFile);
        $config = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return self::getDefaultConfig();
        }
        
        return array_merge(self::getDefaultConfig(), $config);
    }
    
    /**
     * Guarda la configuración en el archivo
     */
    private static function saveConfig($config)
    {
        $dir = dirname(self::$configFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        file_put_contents(self::$configFile, json_encode($config, JSON_PRETTY_PRINT));
    }
    
    /**
     * Obtiene la configuración por defecto
     */
    private static function getDefaultConfig()
    {
        return [
            'whatsapp_access_token' => '',
            'whatsapp_phone_number_id' => '',
            'whatsapp_business_account_id' => '',
            'send_job_notifications' => true,
            'send_invoice_notifications' => true,
            'auto_send_invoices' => false,
            'notification_template' => 'default',
            'webhook_url' => '',
            'webhook_verify_token' => '',
            'debug_mode' => false
        ];
    }
} 