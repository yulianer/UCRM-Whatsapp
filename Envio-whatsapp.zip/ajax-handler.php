<?php

require_once __DIR__ . '/../vendor/autoload.php';

use WhatsAppPlugin\WhatsAppService;
use WhatsAppPlugin\Config;
use WhatsAppPlugin\UCRMIntegration;

header('Content-Type: application/json');

$api = \Ubnt\UcrmPluginSdk\Service\UcrmApi::create();
$security = \Ubnt\UcrmPluginSdk\Service\UcrmSecurity::create();

$user = $security->getUser();
if (!$user || !$user->hasViewPermission(\Ubnt\UcrmPluginSdk\Security\PermissionNames::SCHEDULING_MY_JOBS)) {
    http_response_code(403);
    echo json_encode(['error' => 'No tienes permisos para realizar esta acción']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if (!Config::isWhatsAppConfigured()) {
    echo json_encode(['error' => 'WhatsApp no está configurado']);
    exit;
}

$credentials = Config::getWhatsAppCredentials();
$whatsapp = new WhatsAppService($credentials['access_token'], $credentials['phone_number_id']);
$ucrm = new UCRMIntegration();

switch ($action) {
    case 'send_job_notification':
        $jobId = $_POST['job_id'] ?? 0;
        $job = $ucrm->getJob($jobId);
        
        if (!$job) {
            echo json_encode(['error' => 'Trabajo no encontrado']);
            exit;
        }
        
        $client = $ucrm->getClient($job['clientId']);
        $phone = $client['contacts'][0]['phone'] ?? '';
        
        if (!$phone) {
            echo json_encode(['error' => 'El cliente no tiene número de teléfono registrado']);
            exit;
        }
        
        $result = $whatsapp->sendJobNotification(
            $phone,
            $job['title'],
            date('d/m/Y H:i', strtotime($job['date'])),
            $job['address'] ?? 'No especificada',
            $job['description'] ?? ''
        );
        
        echo json_encode($result);
        break;
        
    case 'send_invoice':
        $invoiceId = $_POST['invoice_id'] ?? 0;
        $invoice = $ucrm->getInvoice($invoiceId);
        
        if (!$invoice) {
            echo json_encode(['error' => 'Factura no encontrada']);
            exit;
        }
        
        $client = $ucrm->getClient($invoice['clientId']);
        $phone = $client['contacts'][0]['phone'] ?? '';
        
        if (!$phone) {
            echo json_encode(['error' => 'El cliente no tiene número de teléfono registrado']);
            exit;
        }
        
        // Generar URL del PDF de la factura
        $invoiceUrl = $_POST['invoice_url'] ?? '';
        if (!$invoiceUrl) {
            // Aquí se podría generar una URL temporal para el PDF
            $invoiceUrl = "https://tu-dominio.com/invoices/{$invoiceId}.pdf";
        }
        
        $result = $whatsapp->sendInvoice($phone, $invoiceUrl, "Factura #{$invoice['number']} - $" . number_format($invoice['total'], 2));
        
        echo json_encode($result);
        break;
        
    case 'send_invoice_notification':
        $invoiceId = $_POST['invoice_id'] ?? 0;
        $invoice = $ucrm->getInvoice($invoiceId);
        
        if (!$invoice) {
            echo json_encode(['error' => 'Factura no encontrada']);
            exit;
        }
        
        $client = $ucrm->getClient($invoice['clientId']);
        $phone = $client['contacts'][0]['phone'] ?? '';
        
        if (!$phone) {
            echo json_encode(['error' => 'El cliente no tiene número de teléfono registrado']);
            exit;
        }
        
        $result = $whatsapp->sendInvoiceNotification(
            $phone,
            $invoice['number'],
            $invoice['total'],
            date('d/m/Y', strtotime($invoice['dueDate']))
        );
        
        echo json_encode($result);
        break;
        
    case 'send_custom_message':
        $phone = $_POST['phone'] ?? '';
        $message = $_POST['message'] ?? '';
        
        if (!$phone || !$message) {
            echo json_encode(['error' => 'Número de teléfono y mensaje son requeridos']);
            exit;
        }
        
        $result = $whatsapp->sendTextMessage($phone, $message);
        echo json_encode($result);
        break;
        
    case 'test_connection':
        $result = $whatsapp->validateConfiguration();
        echo json_encode($result);
        break;
        
    case 'get_client_info':
        $clientId = $_POST['client_id'] ?? 0;
        $client = $ucrm->getClientContactInfo($clientId);
        
        if (!$client) {
            echo json_encode(['error' => 'Cliente no encontrado']);
            exit;
        }
        
        echo json_encode($client);
        break;
        
    case 'get_invoice_info':
        $invoiceId = $_POST['invoice_id'] ?? 0;
        $invoice = $ucrm->getInvoice($invoiceId);
        
        if (!$invoice) {
            echo json_encode(['error' => 'Factura no encontrada']);
            exit;
        }
        
        $client = $ucrm->getClientContactInfo($invoice['clientId']);
        $invoice['client'] = $client;
        
        echo json_encode($invoice);
        break;
        
    case 'get_job_info':
        $jobId = $_POST['job_id'] ?? 0;
        $job = $ucrm->getJob($jobId);
        
        if (!$job) {
            echo json_encode(['error' => 'Trabajo no encontrado']);
            exit;
        }
        
        $client = $ucrm->getClientContactInfo($job['clientId']);
        $job['client'] = $client;
        
        echo json_encode($job);
        break;
        
    default:
        echo json_encode(['error' => 'Acción no válida']);
        break;
} 