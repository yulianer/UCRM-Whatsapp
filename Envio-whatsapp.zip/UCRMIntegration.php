<?php

namespace WhatsAppPlugin;

use Ubnt\UcrmPluginSdk\Service\UcrmApi;

class UCRMIntegration
{
    private $api;
    
    public function __construct()
    {
        $this->api = UcrmApi::create();
    }
    
    /**
     * Obtiene información de un cliente
     */
    public function getClient($clientId)
    {
        return $this->api->get("clients/{$clientId}");
    }
    
    /**
     * Obtiene las facturas de un cliente
     */
    public function getClientInvoices($clientId, $status = null)
    {
        $params = ['clientId' => $clientId];
        
        if ($status !== null) {
            $params['status'] = $status;
        }
        
        return $this->api->get('invoices', $params);
    }
    
    /**
     * Obtiene una factura específica
     */
    public function getInvoice($invoiceId)
    {
        return $this->api->get("invoices/{$invoiceId}");
    }
    
    /**
     * Obtiene el PDF de una factura
     */
    public function getInvoicePdf($invoiceId)
    {
        return $this->api->get("invoices/{$invoiceId}/pdf");
    }
    
    /**
     * Obtiene los trabajos de un cliente
     */
    public function getClientJobs($clientId, $status = null)
    {
        $params = ['clientId' => $clientId];
        
        if ($status !== null) {
            $params['statuses'] = [$status];
        }
        
        return $this->api->get('scheduling/jobs', $params);
    }
    
    /**
     * Obtiene un trabajo específico
     */
    public function getJob($jobId)
    {
        return $this->api->get("scheduling/jobs/{$jobId}");
    }
    
    /**
     * Obtiene todos los trabajos abiertos
     */
    public function getOpenJobs($assignedUserId = null)
    {
        $params = ['statuses' => [0]]; // 0 = abierto
        
        if ($assignedUserId !== null) {
            $params['assignedUserId'] = $assignedUserId;
        }
        
        return $this->api->get('scheduling/jobs', $params);
    }
    
    /**
     * Obtiene las facturas pendientes
     */
    public function getPendingInvoices()
    {
        return $this->api->get('invoices', ['status' => 1]); // 1 = pendiente
    }
    
    /**
     * Actualiza el estado de una factura
     */
    public function updateInvoiceStatus($invoiceId, $status)
    {
        return $this->api->patch("invoices/{$invoiceId}", ['status' => $status]);
    }
    
    /**
     * Obtiene la información de contacto de un cliente
     */
    public function getClientContactInfo($clientId)
    {
        $client = $this->getClient($clientId);
        
        if (!$client) {
            return null;
        }
        
        return [
            'id' => $client['id'],
            'name' => $client['firstName'] . ' ' . $client['lastName'],
            'email' => $client['email'] ?? '',
            'phone' => $client['contacts'][0]['phone'] ?? '',
            'address' => $client['contacts'][0]['address'] ?? '',
            'city' => $client['contacts'][0]['city'] ?? '',
            'state' => $client['contacts'][0]['state'] ?? '',
            'zip' => $client['contacts'][0]['zipCode'] ?? ''
        ];
    }
    
    /**
     * Busca clientes por número de teléfono
     */
    public function findClientByPhone($phone)
    {
        $clients = $this->api->get('clients');
        
        foreach ($clients as $client) {
            if (isset($client['contacts'][0]['phone'])) {
                $clientPhone = preg_replace('/[^0-9]/', '', $client['contacts'][0]['phone']);
                $searchPhone = preg_replace('/[^0-9]/', '', $phone);
                
                if ($clientPhone === $searchPhone) {
                    return $client;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Obtiene estadísticas de facturación
     */
    public function getBillingStats($clientId = null)
    {
        $params = [];
        
        if ($clientId !== null) {
            $params['clientId'] = $clientId;
        }
        
        $invoices = $this->api->get('invoices', $params);
        
        $stats = [
            'total' => 0,
            'pending' => 0,
            'paid' => 0,
            'overdue' => 0
        ];
        
        foreach ($invoices as $invoice) {
            $stats['total'] += $invoice['total'];
            
            switch ($invoice['status']) {
                case 1: // Pendiente
                    $stats['pending'] += $invoice['total'];
                    break;
                case 2: // Pagada
                    $stats['paid'] += $invoice['total'];
                    break;
                case 3: // Vencida
                    $stats['overdue'] += $invoice['total'];
                    break;
            }
        }
        
        return $stats;
    }
    
    /**
     * Obtiene el historial de trabajos de un cliente
     */
    public function getClientJobHistory($clientId, $limit = 10)
    {
        $jobs = $this->api->get('scheduling/jobs', ['clientId' => $clientId]);
        
        // Ordenar por fecha de creación (más reciente primero)
        usort($jobs, function($a, $b) {
            return strtotime($b['createdDate']) - strtotime($a['createdDate']);
        });
        
        return array_slice($jobs, 0, $limit);
    }
} 